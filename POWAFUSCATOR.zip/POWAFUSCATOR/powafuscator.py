import PySimpleGUI as sg
import base64
import os
import re
from pyfiglet import Figlet
from colorama import init, Fore, Style
from datetime import datetime

# Initialize colorama
init()

# Custom theme for POWAFUSCATOR
def set_custom_theme():
    sg.theme_add_new('POWATheme', {
        'BACKGROUND': '#0a2e0a',
        'TEXT': '#c0ffc0',
        'INPUT': '#1e4e1e',
        'TEXT_INPUT': '#ffffff',
        'SCROLL': '#1e4e1e',
        'BUTTON': ('black', '#3aab3a'),
        'PROGRESS': ('#01826B', '#D0D0D0'),
        'BORDER': 1,
        'SLIDER_DEPTH': 0,
        'PROGRESS_DEPTH': 0
    })
    sg.theme('POWATheme')

# Advanced obfuscation techniques
def char_obfuscation(code):
    """Convert each character to [char]ASCII representation"""
    obfuscated = []
    for char in code:
        if char == '\n':
            obfuscated.append("`n")
        elif char == '\t':
            obfuscated.append("`t")
        elif char == '\r':
            obfuscated.append("`r")
        elif char == ' ':
            obfuscated.append("[char]32")
        else:
            obfuscated.append(f"[char]{ord(char)}")
    return '+'.join(obfuscated)

def wrap_in_iex(obfuscated_code):
    """Wrap the obfuscated code in Invoke-Expression"""
    return f"iex(\"{obfuscated_code}\")"

def encode_base64(powershell_code):
    """Convert to Base64 for EncodedCommand"""
    encoded = powershell_code.encode('utf-16le')
    return base64.b64encode(encoded).decode('utf-8')

def full_obfuscation(ps_script):
    """Complete obfuscation pipeline"""
    # Step 1: Char obfuscation
    char_obf = char_obfuscation(ps_script)
    
    # Step 2: IEX wrapping
    iex_wrapped = wrap_in_iex(char_obf)
    
    # Step 3: Base64 encoding
    base64_encoded = encode_base64(iex_wrapped)
    
    # Final command
    final_command = f"powershell -EncodedCommand {base64_encoded}"
    
    return {
        "Char Obfuscation": char_obf,
        "IEX Wrapped": iex_wrapped,
        "Base64 Encoded": base64_encoded,
        "Final Command": final_command
    }

# UI Layout
def create_window():
    set_custom_theme()
    
    menu_def = [['&Help', ['&About', '&Exit']]]
    
    layout = [
        [sg.Menu(menu_def)],
        [sg.Text('POWAFUSCATOR', font=('Courier New', 24, 'bold'), 
                text_color='#3aab3a', pad=((0,0),(10,20)))],
        [sg.Multiline(size=(85, 15), key='-INPUT-', font=('Consolas', 11),
         tooltip='Enter your PowerShell script here', expand_x=True, expand_y=True)],
        [sg.Button('POWAFUSCATE', size=(12, 1), button_color=('black', '#3aab3a')),
         sg.Button('Clear', size=(8, 1)),
         sg.Button('Exit', size=(8, 1))],
        [sg.TabGroup([[sg.Tab('Obfuscation Results', [
                [sg.Multiline(size=(85, 15), key='-OUTPUT-', font=('Consolas', 10),
                             disabled=True, background_color='#0a1a0a', text_color='#3aab3a',
                             expand_x=True, expand_y=True)]
            ]),
            sg.Tab('Command Preview', [
                [sg.Multiline(size=(85, 8), key='-COMMAND-', font=('Consolas', 9),
                 disabled=True, background_color='#0a1a0a', text_color='#aaffaa')],
                [sg.Button('Copy Command', key='-COPY-')]
            ])
        ]], expand_x=True, expand_y=True, tab_background_color='#0a2e0a')],
        [sg.StatusBar('Ready', key='-STATUS-', text_color='#aaffaa', size=(85, 1))]
    ]
    
    return sg.Window('POWAFUSCATOR - Advanced PowerShell Obfuscator', 
                    layout, resizable=True, finalize=True,
                    element_justification='center')

# Main application
def main():
    window = create_window()
    
    while True:
        event, values = window.read()
        
        if event in (sg.WIN_CLOSED, 'Exit'):
            break
            
        if event == 'Clear':
            window['-INPUT-'].update('')
            window['-OUTPUT-'].update('')
            window['-COMMAND-'].update('')
            window['-STATUS-'].update('Cleared all input and output')
            
        if event == 'POWAFUSCATE':
            ps_script = values['-INPUT-'].strip()
            if ps_script:
                try:
                    obfuscated = full_obfuscation(ps_script)
                    output_text = "\n".join(
                        f"{key}:\n{value}\n{'='*50}" 
                        for key, value in obfuscated.items()
                    )
                    window['-OUTPUT-'].update(output_text)
                    window['-COMMAND-'].update(obfuscated['Final Command'])
                    window['-STATUS-'].update('Obfuscation complete!')
                    
                    # Save to output folder
                    if not os.path.exists('output'):
                        os.makedirs('output')
                    timestamp = re.sub(r'[^\d]', '', str(datetime.now()))
                    filename = f"output/obfuscated_{timestamp}.ps1"
                    with open(filename, 'w') as f:
                        f.write(obfuscated['Final Command'])
                    window['-STATUS-'].update(f'Obfuscation saved to {filename}')
                except Exception as e:
                    window['-STATUS-'].update(f'Error: {str(e)}', text_color='red')
            else:
                window['-STATUS-'].update('Please enter PowerShell script first', text_color='red')
                
        if event == '-COPY-':
            command = values['-COMMAND-']
            if command:
                sg.clipboard_set(command)
                window['-STATUS-'].update('Command copied to clipboard!')
                
        if event == 'About':
            sg.popup('POWAFUSCATOR', 
                    'Advanced PowerShell Obfuscation Tool\n'
                    'Version 1.0\n\n'
                    'Obfuscation Techniques:\n'
                    '1. Character-level [char] obfuscation\n'
                    '2. IEX dynamic execution wrapping\n'
                    '3. Base64 encoded command generation',
                    title='About',
                    keep_on_top=True)
    
    window.close()

if __name__ == '__main__':
    main()
